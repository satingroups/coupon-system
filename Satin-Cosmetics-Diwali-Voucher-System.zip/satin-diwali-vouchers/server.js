require("dotenv").config();
const express = require("express");
const Database = require("better-sqlite3");
const QRCode = require("qrcode");
const crypto = require("crypto");
const path = require("path");
const fs = require("fs");
const helmet = require("helmet");
const { rateLimit } = require("express-rate-limit");

const app = express();
app.set("trust proxy", 1);
const PORT = Number(process.env.PORT || 3000);
const STORE = process.env.STORE_NAME || "Satin Cosmetics";
const DEFAULT_DISCOUNT = Math.min(100, Math.max(1, Number(process.env.DEFAULT_DISCOUNT || 20)));
const DEFAULT_EXPIRY = String(process.env.DEFAULT_EXPIRY || "");
const BASE_URL = (process.env.BASE_URL || `http://localhost:${PORT}`).replace(/\/$/, "");
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const SESSION_SECRET = process.env.SESSION_SECRET;

if (!ADMIN_PASSWORD || ADMIN_PASSWORD.length < 12) {
  console.error("ADMIN_PASSWORD must be set and at least 12 characters long.");
  process.exit(1);
}
if (!SESSION_SECRET || SESSION_SECRET.length < 32) {
  console.error("SESSION_SECRET must be set and at least 32 characters long.");
  process.exit(1);
}

const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "vouchers.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
  CREATE TABLE IF NOT EXISTS vouchers (
    id TEXT PRIMARY KEY,
    token_hash TEXT NOT NULL UNIQUE,
    discount INTEGER NOT NULL CHECK(discount BETWEEN 1 AND 100),
    status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK(status IN ('ACTIVE','REDEEMED','REVOKED')),
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL,
    redeemed_at TEXT,
    redeemed_by TEXT,
    note TEXT
  );
  CREATE INDEX IF NOT EXISTS idx_vouchers_status ON vouchers(status);
`);
const insertVoucher = db.prepare(`INSERT INTO vouchers
  (id, token_hash, discount, status, created_at, expires_at, note)
  VALUES (@id, @token_hash, @discount, 'ACTIVE', @created_at, @expires_at, @note)`);
const byHash = db.prepare("SELECT * FROM vouchers WHERE token_hash = ?");
const byId = db.prepare("SELECT id, discount, status, created_at, expires_at, redeemed_at, redeemed_by, note FROM vouchers WHERE id = ?");
const allVouchers = db.prepare("SELECT id, discount, status, created_at, expires_at, redeemed_at, redeemed_by, note FROM vouchers ORDER BY created_at DESC LIMIT 300");

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
      imgSrc: ["'self'", "data:", "blob:"],
      connectSrc: ["'self'"]
    }
  }
}));
app.use(express.json({ limit: "100kb" }));
app.use((req, res, next) => {
  res.setHeader("Permissions-Policy", "camera=(self)");
  next();
});
app.use(express.static(path.join(__dirname, "public")));
app.use("/vendor/html5-qrcode", express.static(path.join(__dirname, "node_modules", "html5-qrcode")));

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: true, legacyHeaders: false });
const apiLimiter = rateLimit({ windowMs: 60 * 1000, limit: 120, standardHeaders: true, legacyHeaders: false, skip: req => req.path === "/health" });

function sha(value) { return crypto.createHash("sha256").update(value).digest("hex"); }
function safeEqual(a, b) {
  const aa = Buffer.from(String(a)); const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function makeSession() {
  const payload = Buffer.from(JSON.stringify({ exp: Date.now() + 8 * 60 * 60 * 1000 })).toString("base64url");
  const sig = crypto.createHmac("sha256", SESSION_SECRET).update(payload).digest("base64url");
  return `${payload}.${sig}`;
}
function isAdmin(req) {
  const value = req.headers.cookie || "";
  const match = value.match(/(?:^|; )satin_session=([^;]+)/);
  if (!match) return false;
  const parts = decodeURIComponent(match[1]).split(".");
  if (parts.length !== 2) return false;
  const expected = crypto.createHmac("sha256", SESSION_SECRET).update(parts[0]).digest("base64url");
  if (!safeEqual(parts[1], expected)) return false;
  try {
    const payload = JSON.parse(Buffer.from(parts[0], "base64url").toString());
    return payload.exp > Date.now();
  } catch { return false; }
}
function requireAdmin(req, res, next) {
  if (!isAdmin(req)) return res.status(401).json({ error: "Please sign in again." });
  next();
}
function newToken() { return crypto.randomBytes(24).toString("base64url"); }
function voucherId() { return "SAT-" + crypto.randomBytes(5).toString("hex").toUpperCase(); }
function businessDate() {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata", year: "numeric", month: "2-digit", day: "2-digit"
  }).format(new Date());
}
function validDate(s) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(`${s}T00:00:00.000Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
}
function publicVoucher(row) {
  return {
    id: row.id, discount: row.discount, status: row.status,
    createdAt: row.created_at, expiresAt: row.expires_at
  };
}
function adminVoucher(row) {
  return { ...publicVoucher(row), redeemedAt: row.redeemed_at, redeemedBy: row.redeemed_by, note: row.note };
}

app.use("/api", apiLimiter);
app.get("/health", (_req, res) => res.json({ ok: true, service: STORE }));

app.post("/api/login", loginLimiter, (req, res) => {
  const password = String(req.body?.password || "");
  if (!safeEqual(password, ADMIN_PASSWORD)) return res.status(401).json({ error: "Incorrect password." });
  const secure = BASE_URL.startsWith("https://");
  res.cookie("satin_session", makeSession(), {
    httpOnly: true, secure, sameSite: "strict", path: "/", maxAge: 8 * 60 * 60 * 1000
  });
  res.json({ ok: true });
});
app.post("/api/logout", (_req, res) => {
  res.clearCookie("satin_session", { httpOnly: true, sameSite: "strict", path: "/" });
  res.json({ ok: true });
});
app.get("/api/session", (req, res) => res.json({ authenticated: isAdmin(req), store: STORE, defaultDiscount: DEFAULT_DISCOUNT, defaultExpiry: DEFAULT_EXPIRY }));

app.get("/api/stats", requireAdmin, (_req, res) => {
  const total = db.prepare("SELECT COUNT(*) n FROM vouchers").get().n;
  const today = businessDate();
  const active = db.prepare("SELECT COUNT(*) n FROM vouchers WHERE status='ACTIVE' AND expires_at >= ?").get(today).n;
  const redeemed = db.prepare("SELECT COUNT(*) n FROM vouchers WHERE status='REDEEMED'").get().n;
  const expired = db.prepare("SELECT COUNT(*) n FROM vouchers WHERE status='ACTIVE' AND expires_at < ?").get(today).n;
  res.json({ total, active, redeemed, expired });
});

app.get("/api/vouchers", requireAdmin, (_req, res) => res.json({ vouchers: allVouchers.all().map(adminVoucher) }));

app.post("/api/vouchers", requireAdmin, async (req, res) => {
  const count = Number(req.body?.count);
  const discount = Number(req.body?.discount);
  const expiresAt = String(req.body?.expiresAt || "");
  const note = String(req.body?.note || "").slice(0, 120);
  if (!Number.isInteger(count) || count < 1 || count > 250) return res.status(400).json({ error: "Choose between 1 and 250 vouchers per batch." });
  if (!Number.isInteger(discount) || discount < 1 || discount > 100) return res.status(400).json({ error: "Discount must be between 1% and 100%." });
  if (!validDate(expiresAt) || expiresAt < businessDate()) return res.status(400).json({ error: "Expiry must be today or a future date." });

  try {
    const created = await Promise.all(Array.from({ length: count }, async () => {
      const token = newToken();
      const v = {
        id: voucherId(), token_hash: sha(token), discount,
        created_at: new Date().toISOString(), expires_at: expiresAt, note,
        url: `${BASE_URL}/v/${token}`
      };
      const qr = await QRCode.toDataURL(v.url, { errorCorrectionLevel: "H", margin: 1, width: 360, color: { dark: "#08090b", light: "#ffffff" } });
      return { ...v, token, qr };
    }));
    const tx = db.transaction(() => created.forEach(v => insertVoucher.run(v)));
    tx();
    res.json({ created: created.map(({ id, discount, expires_at, url, qr }) => ({ id, discount, expiresAt: expires_at, url, qr })) });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Could not create this batch. Please try again." });
  }
});

app.get("/api/verify/:token", (req, res) => {
  const token = String(req.params.token || "");
  if (!/^[A-Za-z0-9_-]{24,80}$/.test(token)) return res.status(404).json({ valid: false, reason: "INVALID" });
  const row = byHash.get(sha(token));
  if (!row) return res.status(404).json({ valid: false, reason: "INVALID" });
  const expired = row.expires_at < businessDate();
  const reason = row.status === "ACTIVE" && expired ? "EXPIRED" : row.status;
  res.json({ valid: reason === "ACTIVE", reason, voucher: publicVoucher(row) });
});

app.post("/api/redeem", requireAdmin, (req, res) => {
  const token = String(req.body?.token || "");
  const staff = String(req.body?.staff || "Satin staff").trim().slice(0, 60);
  if (!/^[A-Za-z0-9_-]{24,80}$/.test(token)) return res.status(400).json({ error: "Invalid QR code." });
  const row = byHash.get(sha(token));
  if (!row) return res.status(404).json({ error: "INVALID VOUCHER", code: "INVALID" });
  if (row.status === "REDEEMED") return res.status(409).json({ error: "ALREADY REDEEMED", code: "REDEEMED", voucher: publicVoucher(row) });
  if (row.status === "REVOKED") return res.status(409).json({ error: "VOUCHER REVOKED", code: "REVOKED", voucher: publicVoucher(row) });
  if (row.expires_at < businessDate()) return res.status(409).json({ error: "EXPIRED VOUCHER", code: "EXPIRED", voucher: publicVoucher(row) });
  const result = db.prepare(`UPDATE vouchers SET status='REDEEMED', redeemed_at=?, redeemed_by=?
    WHERE id=? AND status='ACTIVE'`).run(new Date().toISOString(), staff, row.id);
  if (result.changes !== 1) return res.status(409).json({ error: "ALREADY REDEEMED", code: "REDEEMED" });
  res.json({ ok: true, message: "Voucher redeemed successfully.", voucher: publicVoucher(byId.get(row.id)) });
});

app.post("/api/vouchers/:id/revoke", requireAdmin, (req, res) => {
  const result = db.prepare("UPDATE vouchers SET status='REVOKED' WHERE id=? AND status='ACTIVE'").run(req.params.id);
  if (!result.changes) return res.status(409).json({ error: "Only active vouchers can be revoked." });
  res.json({ ok: true });
});

app.get("/v/:token", (_req, res) => res.sendFile(path.join(__dirname, "public", "voucher.html")));

app.get("/api/qr/:token", async (req, res) => {
  const token = String(req.params.token || "");
  if (!/^[A-Za-z0-9_-]{24,80}$/.test(token) || !byHash.get(sha(token))) return res.status(404).end();
  try {
    const data = await QRCode.toDataURL(`${BASE_URL}/v/${token}`, { errorCorrectionLevel: "H", margin: 1, width: 480, color: { dark: "#08090b", light: "#ffffff" } });
    res.json({ data });
  } catch { res.status(500).json({ error: "QR generation failed." }); }
});

app.listen(PORT, () => console.log(`${STORE} voucher system running on port ${PORT}`));
