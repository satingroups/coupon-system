const token=location.pathname.split("/").filter(Boolean).pop();
const $=id=>document.getElementById(id);
(async()=>{
 try{
  const r=await fetch("/api/verify/"+encodeURIComponent(token));const data=await r.json();
  $("loading").hidden=true;
  if(!data.voucher){$("statusCard").hidden=false;$("statusCard").textContent="This voucher could not be verified. Please contact Satin Cosmetics.";return;}
  const v=data.voucher;
  if(!data.valid){
    $("statusCard").hidden=false;
    $("statusCard").innerHTML=data.reason==="REDEEMED"?"<strong>THIS VOUCHER HAS BEEN REDEEMED</strong>":data.reason==="EXPIRED"?"<strong>THIS VOUCHER HAS EXPIRED</strong>":"<strong>THIS VOUCHER IS NO LONGER ACTIVE</strong>";
    return;
  }
  $("ticket").hidden=false;$("discountValue").textContent=v.discount+"%";$("voucherId").textContent=v.id;$("stubId").textContent=v.id;
  $("expiryLabel").textContent="VALID UNTIL "+new Date(v.expiresAt+"T00:00:00").toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"}).toUpperCase();
  const qr=await fetch("/api/qr/"+encodeURIComponent(token));
  const qrData=await qr.json();
  if(!qr.ok) throw new Error("QR code unavailable.");
  $("qr").src=qrData.data;
 }catch(e){$("loading").textContent="Unable to load this voucher. Please try again.";}
})();
