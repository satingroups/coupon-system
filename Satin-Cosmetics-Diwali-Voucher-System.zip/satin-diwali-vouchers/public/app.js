const $ = id => document.getElementById(id);
let scanner = null;
const fmt = d => new Date(d).toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"});
async function api(url, options={}) {
  const r = await fetch(url,{...options,headers:{"Content-Type":"application/json",...(options.headers||{})}});
  const data = await r.json().catch(()=>({}));
  if (!r.ok) throw Object.assign(new Error(data.error||"Request failed"),{data,status:r.status});
  return data;
}
function showLogin(){ $("loginView").hidden=false; $("dashboard").hidden=true; }
function showDashboard(){ $("loginView").hidden=true; $("dashboard").hidden=false; loadDashboard(); }
$("loginForm").addEventListener("submit",async e=>{
  e.preventDefault(); $("loginError").textContent="";
  try{await api("/api/login",{method:"POST",body:JSON.stringify({password:$("password").value})});showDashboard();}
  catch(err){$("loginError").textContent=err.message;}
});
$("logout").onclick=async()=>{await api("/api/logout",{method:"POST"});showLogin();};
async function loadDashboard(){
  try{
    const s=await api("/api/stats"); $("sTotal").textContent=s.total;$("sActive").textContent=s.active;$("sRedeemed").textContent=s.redeemed;$("sExpired").textContent=s.expired;
    const {vouchers}=await api("/api/vouchers");
    $("voucherRows").innerHTML=vouchers.map(v=>`<tr><td><b>${v.id}</b></td><td>${v.discount}%</td><td><span class="status ${v.status.toLowerCase()}">${v.status}</span></td><td>${fmt(v.expiresAt)}</td><td>${v.status==="ACTIVE"?`<button class="text-button" data-revoke="${v.id}">Revoke</button>`:""}</td></tr>`).join("")||'<tr><td colspan="5" class="muted">No vouchers issued yet.</td></tr>';
    document.querySelectorAll("[data-revoke]").forEach(b=>b.onclick=async()=>{if(confirm("Revoke "+b.dataset.revoke+"?")){await api("/api/vouchers/"+b.dataset.revoke+"/revoke",{method:"POST"});loadDashboard();}});
  }catch(e){if(e.message.includes("sign in"))showLogin();}
}
$("refresh").onclick=loadDashboard;
function dateInThirtyDays() {
  const d = new Date(); d.setDate(d.getDate() + 30);
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}
$("expiry").value = dateInThirtyDays();
$("createForm").addEventListener("submit", async e => {
  e.preventDefault();
  const msg = $("createMessage");
  const printTab = window.open("about:blank", "_blank");
  if (!printTab) { msg.textContent = "Allow pop-ups for this site, then generate the batch again."; return; }
  printTab.document.write("<title>Preparing Satin voucher sheet…</title><p style='font:16px Arial;padding:24px'>Preparing your secure voucher sheet…</p>");
  msg.textContent = "Creating unique vouchers and QR codes…";
  try {
    const result = await api("/api/vouchers", { method: "POST", body: JSON.stringify({
      discount: $("discount").value, count: $("count").value,
      expiresAt: $("expiry").value, note: $("note").value
    }) });
    const cards = result.created.map(v => `
      <article class="ticket">
        <div class="ticket-main">
          <div class="kicker">SATIN COSMETICS <span>✦ THE FESTIVE EDITION</span></div>
          <div class="headline">A little<br><i>more glow.</i></div>
          <div class="offer"><b>${v.discount}%</b><span>OFF YOUR<br>PURCHASE</span></div>
          <div class="meta"><span>${v.id}</span><span>ONE MOMENT · ONE REDEMPTION</span></div>
          <svg class="diya" viewBox="0 0 100 100" aria-hidden="true"><path d="M50 8 C34 27 38 37 50 43 C62 37 66 27 50 8Z" fill="none" stroke="#d7dbe1" stroke-width="2.2"/><path d="M20 51 C25 72 75 72 80 51 C64 60 36 60 20 51Z" fill="none" stroke="#d7dbe1" stroke-width="2.2"/><path d="M28 64 Q50 76 72 64 M50 44 V51 M14 39 L22 44 M86 39 L78 44" fill="none" stroke="#aeb5bf" stroke-width="1.5"/></svg>
        </div>
        <aside class="stub"><small>YOUR PRIVILEGE</small><img src="${v.qr}" alt="Voucher QR"><b>${v.id}</b><small>VALID UNTIL ${v.expiresAt}</small></aside>
      </article>`).join("");
    printTab.document.open();
    printTab.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>Satin Cosmetics · Diwali voucher batch</title>
      <style>
      *{box-sizing:border-box}body{margin:0;padding:18px;background:#fff;color:#f4f4f1;font-family:Arial,sans-serif}.toolbar{margin:0 auto 16px;max-width:1000px;color:#111;display:flex;justify-content:space-between;align-items:center}.toolbar button{padding:10px 16px;background:#111;color:#fff;border:0;border-radius:4px;cursor:pointer}.grid{max-width:1000px;margin:auto;display:grid;grid-template-columns:1fr 1fr;gap:13px}.ticket{height:190px;background:linear-gradient(125deg,#24272c,#090a0c 66%,#32363c);border:1px solid #9298a1;border-radius:12px;display:grid;grid-template-columns:1fr 116px;overflow:hidden;break-inside:avoid;position:relative}.ticket-main{padding:15px 17px;position:relative;border-right:1px dashed #c3c7ce}.ticket-main:after{content:'';position:absolute;right:-8px;top:calc(50% - 8px);width:16px;height:16px;border-radius:100%;background:white}.kicker{font-size:8px;letter-spacing:2px;color:#bec3cb}.kicker span{float:right}.headline{font-size:28px;line-height:.92;font-weight:800;letter-spacing:-1.5px;margin-top:13px}.headline i{font-family:Georgia,serif;font-weight:400;color:#c2c6cd}.offer{display:flex;align-items:center;gap:8px;margin-top:5px}.offer b{font-size:35px;letter-spacing:-2px;background:linear-gradient(90deg,#fff,#9ea4ac);color:transparent;background-clip:text}.offer span{font:8px monospace;letter-spacing:1px;line-height:1.3;color:#ddd}.meta{position:absolute;bottom:11px;left:17px;right:14px;display:flex;justify-content:space-between;font:7px monospace;letter-spacing:1px;color:#bfc3c9}.diya{position:absolute;right:18px;top:44px;width:70px;height:70px;opacity:.45}.stub{background:linear-gradient(145deg,#e7e9ec,#a9afb8);color:#16191e;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px}.stub img{width:78px;height:78px}.stub b{font:8px monospace}.stub small{font:7px monospace;letter-spacing:1px}@media print{body{padding:0}.toolbar{display:none}.grid{gap:8px}.ticket{height:178px;print-color-adjust:exact;-webkit-print-color-adjust:exact}}@page{size:A4;margin:8mm}
      </style></head><body><div class="toolbar"><b>SATIN COSMETICS · DIWALI PRIVILEGE</b><button onclick="window.print()">Print voucher batch ↗</button></div><main class="grid">${cards}</main></body></html>`);
    printTab.document.close();
    msg.textContent = `Created ${result.created.length} vouchers. The printable ticket sheet is ready in a new tab.`;
    loadDashboard();
  } catch (err) {
    printTab.close();
    msg.textContent = err.message;
  }
});
function extractToken(raw){raw=raw.trim();try{const u=new URL(raw);return u.pathname.split("/").filter(Boolean).pop()||raw;}catch{return raw;}}
async function verifyAndRedeem(raw){
  const token=extractToken(raw);$("verifyResult").className="verify-result";$("verifyResult").innerHTML="Checking voucher…";
  try{
    const v=await api("/api/verify/"+encodeURIComponent(token));
    if(!v.valid){$("verifyResult").className="verify-result bad";$("verifyResult").textContent=v.reason==="REDEEMED"?"ALREADY REDEEMED":v.reason==="EXPIRED"?"EXPIRED VOUCHER":"VOUCHER NOT VALID";return;}
    const x=v.voucher;
    $("verifyResult").className="verify-result good";
    $("verifyResult").innerHTML=`<div class="result-kicker">AUTHENTIC VOUCHER</div><strong>${x.discount}% OFF</strong><div>${x.id} · Valid until ${fmt(x.expiresAt)}</div><button id="redeemNow" class="button silver full">Confirm redemption</button>`;
    $("redeemNow").onclick=async()=>{try{const done=await api("/api/redeem",{method:"POST",body:JSON.stringify({token,staff:$("staffName").value})});$("verifyResult").className="verify-result good";$("verifyResult").innerHTML=`<strong>✓ REDEEMED</strong><div>${done.voucher.id} · ${done.voucher.discount}% discount applied</div>`;loadDashboard();}catch(err){$("verifyResult").className="verify-result bad";$("verifyResult").textContent=err.message;}};
  }catch(err){$("verifyResult").className="verify-result bad";$("verifyResult").textContent=err.message;}
}
$("manualForm").onsubmit=e=>{e.preventDefault();verifyAndRedeem($("manualToken").value);};
$("startScan").onclick=async()=>{
  if(!window.Html5Qrcode){$("verifyResult").textContent="Camera scanner library could not load. Use manual code entry.";return;}
  try{
    scanner=new Html5Qrcode("reader");await scanner.start({facingMode:"environment"},{fps:10,qrbox:{width:220,height:220}},async text=>{await scanner.stop();$("startScan").disabled=false;$("stopScan").disabled=true;$("manualToken").value=text;verifyAndRedeem(text);});
    $("startScan").disabled=true;$("stopScan").disabled=false;
  }catch(e){$("verifyResult").textContent="Camera unavailable. Check browser permission and use HTTPS, or enter the code manually.";}
};
$("stopScan").onclick=async()=>{if(scanner){await scanner.stop();scanner=null;}$("startScan").disabled=false;$("stopScan").disabled=true;};
(async()=>{
  try {
    const s = await api("/api/session");
    $("discount").value = s.defaultDiscount || 20;
    if (s.defaultExpiry && /^\d{4}-\d{2}-\d{2}$/.test(s.defaultExpiry) && s.defaultExpiry >= dateInThirtyDays().slice(0,10)) {
      $("expiry").value = s.defaultExpiry;
    }
    s.authenticated ? showDashboard() : showLogin();
  } catch { showLogin(); }
})();
