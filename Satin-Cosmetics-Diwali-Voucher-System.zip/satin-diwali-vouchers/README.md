# Satin Cosmetics — Diwali QR Voucher System

A self-hosted QR voucher generator and redemption app. The Node.js server, SQLite database, QR generation, staff dashboard and public voucher page are included. No Supabase, Firebase or external database is required.

## Features

- Create 1–250 vouchers per batch with a chosen discount and expiry.
- Every voucher receives a cryptographically random QR URL and unique Satin ID.
- Print a batch sheet from the admin dashboard.
- Customer-facing perforated black-and-silver Diwali ticket.
- Staff camera scanner and manual URL/token entry.
- Server-side verification and one-time redemption.
- SQLite persistence, admin session cookie, login rate limit, security headers.
- Revoke an active voucher.

## Requirements

- Node.js 20 or newer.
- For production: a host that supports Node/Docker and persistent disk storage.

## Run locally

1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Set a strong `ADMIN_PASSWORD` (at least 12 characters), a random `SESSION_SECRET` (at least 32 characters), and `BASE_URL=http://localhost:3000`.
4. In this folder run:

   ```bash
   npm install
   npm start
   ```

5. Open `http://localhost:3000`.

The app loads `.env` automatically. The database is created at `data/vouchers.sqlite`. The QR scanner library is served by the app itself; it does not rely on a third-party script CDN.

## Deploy without a backend CLI

### Render (Docker)

1. Create a GitHub repository and upload the contents of this ZIP.
2. In Render, choose **New → Blueprint**, connect the repository, and let Render read `render.yaml`.
3. Set `ADMIN_PASSWORD` to a strong unique password. Render generates `SESSION_SECRET` for you.
4. Deploy the service. Once Render assigns the public HTTPS URL, set `BASE_URL` to that exact URL and redeploy.
5. The Blueprint attaches a persistent disk at `/app/data`, where SQLite stores voucher records across restarts and deployments.

You do not need to install or run a backend CLI. Deployment still requires a hosting account and a public server URL. **Important:** Render's persistent disks are available on paid web services, so this SQLite deployment is not a free always-on setup. Review the current service and disk charges before creating it.

### Other Docker hosts

Build and run the included Dockerfile. Mount a persistent volume at `/app/data`, and set `ADMIN_PASSWORD`, `SESSION_SECRET`, and `BASE_URL`.

## Important operating notes

- Set `BASE_URL` to the exact public HTTPS origin before issuing vouchers. QR links are generated using this value.
- Do not issue production vouchers while using `localhost`.
- Do not commit `.env`, passwords, or the `data/` directory to GitHub.
- Keep the hosting persistent disk attached. If the SQLite database is lost, the system will no longer know which vouchers were issued or redeemed.
- Staff must be signed in to redeem. Public voucher pages only show validity; they cannot redeem themselves.
- Voucher expiry and dashboard expiry totals use India Standard Time (Asia/Kolkata).
- A voucher is marked redeemed on the server. Repeated scans cannot redeem it again.
- The dashboard's camera scanner requires HTTPS (or localhost) and camera permission. Manual token/URL entry is also available.
- This is a starter operational system. Before high-volume commercial use, have the deployment and security configuration reviewed and test backups, restore, access controls and store-specific terms.

## Customization

- Store name: `STORE_NAME`
- Default discount shown in the form: `DEFAULT_DISCOUNT` (defaults to 20%).
- Optional prefilled expiry date: `DEFAULT_EXPIRY`; leave blank to default to 30 days from opening.
- Visual styles: `public/styles.css`
- Voucher layout: `public/voucher.html` and `public/voucher.js`

## API overview

- `POST /api/login` — staff/admin login
- `GET /api/session` — session state
- `GET /api/stats` — admin statistics
- `GET /api/vouchers` — recent voucher records
- `POST /api/vouchers` — create a voucher batch
- `GET /api/verify/:token` — public voucher validity
- `GET /api/qr/:token` — server-generated QR image data
- `POST /api/redeem` — authenticated one-time redemption
- `POST /api/vouchers/:id/revoke` — revoke an active voucher

## Voucher status meanings

- `ACTIVE`: valid if not expired.
- `REDEEMED`: already used; cannot be used again.
- `REVOKED`: cancelled by staff.
- `EXPIRED`: derived from the expiry date.
